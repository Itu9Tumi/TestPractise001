import 'dart:async';

Future<void> main() async {
  "class"; var name;
 name;
 Mani;
 Age; 30;
 
 Announcement;var february;
february;
  }

class Birthday {
}

class Age {
}

class Mani {
}

class Announcement {
}

